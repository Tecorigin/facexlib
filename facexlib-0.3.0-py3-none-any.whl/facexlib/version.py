# GENERATED VERSION FILE
# TIME: Wed Jul 30 13:57:29 2025
__version__ = '0.3.0'
__gitsha__ = '359e942'
version_info = (0, 3, 0)
